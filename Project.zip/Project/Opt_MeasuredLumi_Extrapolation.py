##############################################################################################################################################
# @Giulia Faletti
# Extrapolating the luminosity evolution for smaller or longer fill times
# based on the optimization model proposed
##############################################################################################################################################
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import LoadData as ld
import LuminosityOptimization as lo
import scipy.integrate as integrate
from lmfit import Model
import time 

#defining the start time of the code
start=time.time()

#loading data
data_16, data_17, data_18, array16, array17, array18 = ld.Data()
data_tot, dataTot, arrayTot = ld.TotalDataSet(data_16, data_17, data_18)
data_ta16, data_tf16, data_ta17, data_tf17, data_ta18, data_tf18 = ld.loadFill()     
FillNumber16, FillNumber17, FillNumber18 = ld.FillNumber()
data_16_sec, data_ta16_sec, data_tf16_sec, data_17_sec, data_ta17_sec,\
   data_tf17_sec, data_18_sec, data_ta18_sec, data_tf18_sec=ld.Data_sec(array16,\
      data_ta16, data_tf16, array17, data_ta17, data_tf17, array18, data_ta18, data_tf18)

#defining the fit function
def fit(x, a, b, c, d):
    return (a*np.exp((-b)*x))+(c*np.exp((-d)*x))

#defining the fit model
model=Model(fit)

#2016
L_int_opt2016=[]
for i in range(len(FillNumber16)):
     print(i)
     n_i, k_b, B_s, E_s, B_r, G_r, S_int, n_c, N_i, T_hc, T_ph, S_z, S_s, Fe, f_rev, Xi, Eps= lo.Parameters2016() #importing the theoretical luminosity model parameters
     print("######################################################################FILL",int(FillNumber16[i]),"#########################################################")
     text = str(int(FillNumber16[i])) #number of current fill
     #obtain the Times and luminosity evolution values for that fill
     f=open('ATLAS/ATLAS_fill_2016/{}_lumi_ATLAS.txt'.format(text),"r")
     lines=f.readlines()
     L_evolx=[]
     times=[]
     for x in lines:
        times.append(int(x.split(' ')[0]))  
        L_evolx.append(float(x.split(' ')[2]))
          
     f.close()
     Times = np.array(times)
     L_evol = np.array(L_evolx)
     
     #evaluate the optimal time for the current fill
     t_opt = lo.t_opt_eval(N_i, n_c, Xi, S_int, data_ta16_sec[i])
     print("t_opt=", t_opt,"Last time=", Times[len(Times)-1], "ta=", data_ta16_sec[i])
     
     #compare the optimal time with the last value of the Times array
     t_opt = Times[0]+t_opt
     print("Times[0]+t_opt=", t_opt)
     control = t_opt>Times[len(Times)-1]   
     print("Times[0]+t_opt=", t_opt, "Extrapolation needed:", control)
     limit=Times[len(Times)-1] #last value of the Times array
     
     #performing extrapolation when needed
     if int(t_opt)>limit:
         
        X = np.arange(limit+60, int(t_opt), 60) #definition of the extrapolation interval
        #looking the evolution of luminosity backward searching for high differences in subsequant data 
        L_rev=[]
        T_rev=[]
        for r in reversed(L_evol):
            L_rev.append(r)
        for r in reversed(Times):
            T_rev.append(r)    
        
        L_rev=np.array(L_rev)
        T_rev=np.array(T_rev)
        
        x=[]
        y=[]
        x=np.array(x)
        y=np.array(y)
        for i in range(len(L_rev)-1):
            if L_rev[i] < 1e3 or abs(L_rev[i+1]-L_rev[i])>5e3:
                    continue
            elif abs(L_rev[i+1]-L_rev[i])<5e3:
                    y=np.append(y, L_rev[i])
                    x=np.append(x, T_rev[i])
            elif  len(y)>20:
                  break     
        
        #coming back to forward L_evol           
        x_rev=[]
        y_rev=[]
        for r in reversed(x):
            x_rev.append(r)
        for r in reversed(y):
            y_rev.append(r)  
            
        x=np.array(x_rev).flatten('F')
        y=np.array(y_rev).flatten('F')          
           
        #normalization of the time interval    
        norm_x=[]
        norm_x=np.array(norm_x)
        norm_X=[]
        norm_X=np.array(norm_X)
        for element in x:
            z=(element-np.amin(x))/(np.amax(X)-np.amin(x))
            norm_x=np.append(norm_x, z)
    
        for element in X:
            z=(element-np.amin(x))/(np.amax(X)-np.amin(x))
            norm_X=np.append(norm_X, z)  
             
        
        #performing fit of last segments of data
        fit_result=model.fit(y, x=norm_x, a=1, b=0.2, c=1, d=0.2)
        Y = fit(norm_X, fit_result.params['a'].value, fit_result.params['b'].value, fit_result.params['c'].value, fit_result.params['d'].value)
        print(fit_result.params['a'].value, fit_result.params['b'].value, fit_result.params['c'].value, fit_result.params['d'].value)
        
        #avoiding positive exponential
        if fit_result.params['b'].value < -1 or fit_result.params['d'].value < -1: # or (fit_result.params['b'].value < 0 and fit_result.params['d'].value < 0):
            def fit_lin(x, a2, b2):
                return (a2*x)-b2

            model2=Model(fit_lin)
            fit_result2=model2.fit(y, x=norm_x, a2=1, b2=1)
            Y = fit_lin(norm_X, fit_result2.params['a2'].value, fit_result2.params['b2'].value)
            Y2=[]
            X2=[]
            for index in range(len(Y)):
                if Y[index] > 0.0:
                    Y2.append(Y[index])
                    X2.append(X[index])
            
            Y=np.array(Y2)
            X=np.array(X2)     
        #redefining the luminosity evolution and the time interval
        L=[]
        T=[]
        for l in range(len(L_evol)):
            if L_evol[l] <=1.0:
                continue
            elif L_evol[l]>1.0:
                L.append(L_evol[l])
                T.append(Times[l])
        L=np.array(L)
        T=np.array(T)        
        Times= np.append(T, X)
        L_evol = np.append(L, Y) 

         
             
     k=0 
     Lumi_evol=[]
     Time=[]
     for m in Times:
       if int(t_opt)>=m:
         Lumi_evol.append(L_evol[k])
         Time.append(Times[k])
         k=k+1
           

     Lumi_evol = np.array(Lumi_evol).flatten('F')
     Time = np.array(Time).flatten('F')
     
     #normalizing the time interval 
     norm_Time=[]
     norm_Time=np.array(norm_Time)
     for t in Time:
        z=(t-np.amin(Time))/(np.amax(Time)-np.amin(Time))
        norm_Time=np.append(norm_Time, z)
     Time1=Time   
     Time=norm_Time
     
     #plotting results 
     plt.close("all")
     fig,  ax = plt.subplots()
     ax.plot(Time, Lumi_evol*1e30, "r-", label='Luminosity Evolution')
     #ax.legend(loc='best')
     ax.set_xlabel("Normalized Times")
     ax.set_ylabel("Luminosity [cm^-2 s^-1]")
     ax.set_title('Luminosity evolution of optimal fill {}'.format(text))
     plt.savefig('ATLAS/OptimalFillsLuminosityEvolution2016/{}_Opt_Lumi_Evol.pdf'.format(text)) 
     
     #evaluating the fill integral luminosity
     L_int_opt = integrate.simps(Lumi_evol*1e30, Time1)
     L_int_opt2016.append(L_int_opt)

#2017   
L_int_opt2017=[]  
for i in range(len(FillNumber17)):
     print(i)
     n_i, k_b, B_s, E_s, B_r, G_r, S_int, n_c, N_i, T_hc, T_ph, S_z, S_s, Fe, f_rev, Xi, Eps= lo.Parameters2017() #importing the theoretical luminosity model parameters
     print("######################################################################FILL",int(FillNumber17[i]),"#########################################################")
     text = str(int(FillNumber17[i])) #number of current fill
     #obtain the Times and luminosity evolution values for that fill
     f=open('ATLAS/ATLAS_fill_2017/{}_lumi_ATLAS.txt'.format(text),"r")
     lines=f.readlines()
     L_evolx=[]
     times=[]
     for x in lines:
        times.append(int(x.split(' ')[0]))  
        L_evolx.append(float(x.split(' ')[2]))
          
     f.close()
     Times = np.array(times)
     L_evol = np.array(L_evolx)
     
     #evaluate the optimal time for the current fill
     t_opt = lo.t_opt_eval(N_i, n_c, Xi, S_int, data_ta17_sec[i])
     print("t_opt=", t_opt,"Last time=", Times[len(Times)-1], "ta=", data_ta17_sec[i])
     
     #compare the optimal time with the last value of the Times array
     t_opt = Times[0]+t_opt
     print("Times[0]+t_opt=", t_opt)
     control = t_opt>Times[len(Times)-1]   
     print("Times[0]+t_opt=", t_opt, "Extrapolation needed:", control)
     limit=Times[len(Times)-1] #last value of the Times array
     
     #performing extrapolation when needed
     if int(t_opt)>limit:
         
        X = np.arange(limit+60, int(t_opt), 60) #definition of the extrapolation interval
        #looking the evolution of luminosity backward searching for high differences in subsequant data 
        L_rev=[]
        T_rev=[]
        for r in reversed(L_evol):
            L_rev.append(r)
        for r in reversed(Times):
            T_rev.append(r)    
        
        L_rev=np.array(L_rev)
        T_rev=np.array(T_rev)
        
        x=[]
        y=[]
        x=np.array(x)
        y=np.array(y)
        for i in range(len(L_rev)-1):
            if L_rev[i] < 1e3 or abs(L_rev[i+1]-L_rev[i])>5e3:
                    continue
            elif abs(L_rev[i+1]-L_rev[i])<5e3:
                    y=np.append(y, L_rev[i])
                    x=np.append(x, T_rev[i])
            elif  len(y)>20:
                  break    
                   
        x_rev=[]
        y_rev=[]
        for r in reversed(x):
            x_rev.append(r)
        for r in reversed(y):
            y_rev.append(r)  
            
        x=np.array(x_rev).flatten('F')
        y=np.array(y_rev).flatten('F')          
           
        #normalization of the time interval    
        norm_x=[]
        norm_x=np.array(norm_x)
        norm_X=[]
        norm_X=np.array(norm_X)
        for element in x:
            z=(element-np.amin(x))/(np.amax(X)-np.amin(x))
            norm_x=np.append(norm_x, z)
    
        for element in X:
            z=(element-np.amin(x))/(np.amax(X)-np.amin(x))
            norm_X=np.append(norm_X, z)  
             
        
        #performing fit of last segments of data
        fit_result=model.fit(y, x=norm_x, a=1, b=0.2, c=1, d=0.2)
        Y = fit(norm_X, fit_result.params['a'].value, fit_result.params['b'].value, fit_result.params['c'].value, fit_result.params['d'].value)
        print(fit_result.params['a'].value, fit_result.params['b'].value, fit_result.params['c'].value, fit_result.params['d'].value)
        
        #avoiding positive exponential
        if fit_result.params['b'].value < -1 or fit_result.params['d'].value < -1: #or (fit_result.params['b'].value < 0.0 and fit_result.params['d'].value < 0.0):
            def fit_lin(x, a2, b2):
                return (a2*x)-b2

            model2=Model(fit_lin)
            fit_result2=model2.fit(y, x=norm_x, a2=1, b2=1)
            Y = fit_lin(norm_X, fit_result2.params['a2'].value, fit_result2.params['b2'].value)
            Y2=[]
            X2=[]
            for index in range(len(Y)):
                if Y[index] > 0.0:
                    Y2.append(Y[index])
                    X2.append(X[index])
            
            Y=np.array(Y2)
            X=np.array(X2)        

        #redefining the luminosity evolution and the time interval
        L=[]
        T=[]
        for l in range(len(L_evol)):
            if L_evol[l] <=1.0:
                continue
            elif L_evol[l]>1.0:
                L.append(L_evol[l])
                T.append(Times[l])
        L=np.array(L)
        T=np.array(T)        
        Times= np.append(T, X)
        L_evol = np.append(L, Y) 

         
     #saving all the values of luminosity and correspondent time that are smaller than the optimal fill time        
     k=0 
     Lumi_evol=[]
     Time=[]
     for m in Times:
       if int(t_opt)>=m:
         Lumi_evol.append(L_evol[k])
         Time.append(Times[k])
         k=k+1
           

     Lumi_evol = np.array(Lumi_evol).flatten('F')
     Time = np.array(Time).flatten('F')
     
     #normalizing the time interval 
     norm_Time=[]
     norm_Time=np.array(norm_Time)
     for t in Time:
        z=(t-np.amin(Time))/(np.amax(Time)-np.amin(Time))
        norm_Time=np.append(norm_Time, z)
     Time1=Time   
     Time=norm_Time
     
     #plotting the results 
     plt.close("all")
     fig,  ax = plt.subplots()
     ax.plot(Time, Lumi_evol*1e30, "r-", label='Luminosity Evolution')
     ax.set_xlabel("Normalized Times")
     ax.set_ylabel("Luminosity [cm^-2 s^-1]")
     ax.set_title('Luminosity evolution of optimal fill {}'.format(text))
     plt.savefig('ATLAS/OptimalFillsLuminosityEvolution2017/{}_Opt_Lumi_Evol.pdf'.format(text)) 
    
     #evaluating the fill integral luminosity
     L_int_opt = integrate.simpson(Lumi_evol*1e30, Time1)
     L_int_opt2017.append(L_int_opt)
     
#2018
L_int_opt2018=[]
for i in range(len(FillNumber18)):
     print(i)
     n_i, k_b, B_s, E_s, B_r, G_r, S_int, n_c, N_i, T_hc, T_ph, S_z, S_s, Fe, f_rev, Xi, Eps= lo.Parameters2018() #importing the theoretical luminosity model parameters
     print("######################################################################FILL",int(FillNumber18[i]),"#########################################################")
     text = str(int(FillNumber18[i])) #number of current fill
     #obtain the Times and luminosity evolution values for that fill
     f=open('ATLAS/ATLAS_fill_2018/{}_lumi_ATLAS.txt'.format(text),"r")
     lines=f.readlines()
     L_evolx=[]
     times=[]
     for x in lines:
        times.append(int(x.split(' ')[0]))  
        L_evolx.append(float(x.split(' ')[2]))
          
     f.close()
     Times = np.array(times)
     L_evol = np.array(L_evolx)
     
     #evaluate the optimal time for the current fill
     t_opt = lo.t_opt_eval(N_i, n_c, Xi, S_int, data_ta18_sec[i])
     print("t_opt=", t_opt,"Last time=", Times[len(Times)-1], "ta=", data_ta18_sec[i])
     
     #compare the optimal time with the last value of the Times array
     t_opt = Times[0]+t_opt
     print("Times[0]+t_opt=", t_opt)
     control = t_opt>Times[len(Times)-1]   
     print("Times[0]+t_opt=", t_opt, "Extrapolation needed:", control)
     limit=Times[len(Times)-1] #last value of the Times array
     
     #performing extrapolation when needed
     if int(t_opt)>limit:
         
        X = np.arange(limit+60, int(t_opt), 60) #definition of the extrapolation interval
        
        #looking the evolution of luminosity backward searching for high differences in subsequant data 
        L_rev=[]
        T_rev=[]
        for r in reversed(L_evol):
            L_rev.append(r)
        for r in reversed(Times):
            T_rev.append(r)    
        
        L_rev=np.array(L_rev)
        T_rev=np.array(T_rev)
        
        x=[]
        y=[]
        x=np.array(x)
        y=np.array(y)
        for i in range(len(L_rev)-1):
            if L_rev[i] < 1.0 or abs(L_rev[i+1]-L_rev[i])>5e3: #il primo da modificare dopo aver controllato i fills
                    continue
            elif abs(L_rev[i+1]-L_rev[i])<5e3:
                    y=np.append(y, L_rev[i])
                    x=np.append(x, T_rev[i])
            elif  len(y)>20:
                  break        
                   
        x_rev=[]
        y_rev=[]
        for r in reversed(x):
            x_rev.append(r)
        for r in reversed(y):
            y_rev.append(r)  
            
        x=np.array(x_rev).flatten('F')
        y=np.array(y_rev).flatten('F')          
           
        #normalization of the time interval    
        norm_x=[]
        norm_x=np.array(norm_x)
        norm_X=[]
        norm_X=np.array(norm_X)
        for element in x:
            z=(element-np.amin(x))/(np.amax(X)-np.amin(x))
            norm_x=np.append(norm_x, z)
    
        for element in X:
            z=(element-np.amin(x))/(np.amax(X)-np.amin(x))
            norm_X=np.append(norm_X, z)      
        
        #performing fit of last segments of data
        fit_result=model.fit(y, x=norm_x, a=1, b=0.2, c=1, d=0.2)
        Y = fit(norm_X, fit_result.params['a'].value, fit_result.params['b'].value, fit_result.params['c'].value, fit_result.params['d'].value)
        print(fit_result.params['a'].value, fit_result.params['b'].value, fit_result.params['c'].value, fit_result.params['d'].value)
        
        #avoiding positive exponential
        if fit_result.params['b'].value < -1 or fit_result.params['d'].value < -1:# or (fit_result.params['b'].value < 0 and fit_result.params['d'].value < 0):
            def fit_lin(x, a2, b2):
                return (a2*x)-b2

            model2=Model(fit_lin)
            fit_result2=model2.fit(y, x=norm_x, a2=1, b2=1)
            Y = fit_lin(norm_X, fit_result2.params['a2'].value, fit_result2.params['b2'].value)
            Y2=[]
            X2=[]
            for index in range(len(Y)):
                if Y[index] > 0.0:
                    Y2.append(Y[index])
                    X2.append(X[index])
            
            Y=np.array(Y2)
            X=np.array(X2)    

        #redefining the luminosity evolution and the time interval
        L=[]
        T=[]
        for l in range(len(L_evol)):
            if L_evol[l] <=1.0:
                continue
            elif L_evol[l]>1.0:
                L.append(L_evol[l])
                T.append(Times[l])
        L=np.array(L)
        T=np.array(T)        
        Times= np.append(T, X)
        L_evol = np.append(L, Y) 

         
     #saving all the values of luminosity and correspondent time that are smaller than the optimal fill time         
     k=0 
     Lumi_evol=[]
     Time=[]
     for m in Times:
       if int(t_opt)>=m:
         Lumi_evol.append(L_evol[k])
         Time.append(Times[k])
         k=k+1
           

     Lumi_evol = np.array(Lumi_evol).flatten('F')
     Time = np.array(Time).flatten('F')
     
     #normalizing the time interval 
     norm_Time=[]
     norm_Time=np.array(norm_Time)
     for t in Time:
        z=(t-np.amin(Time))/(np.amax(Time)-np.amin(Time))
        norm_Time=np.append(norm_Time, z)
     Time1=Time    
     Time=norm_Time
     
     #plotting the results 
     plt.close("all")
     fig,  ax = plt.subplots()
     ax.plot(Time, Lumi_evol*1e30, "r-", label='Luminosity Evolution')
     ax.set_xlabel("Normalized Times")
     ax.set_ylabel("Luminosity [cm^-2 s^-1]")
     ax.set_title('Luminosity evolution of optimal fill {}'.format(text))
     plt.savefig('ATLAS/OptimalFillsLuminosityEvolution2018/{}_Opt_Lumi_Evol.pdf'.format(text))
     
     #evaluating the fill integral luminosity
     L_int_opt = integrate.simpson(Lumi_evol*1e30, Time1)
     L_int_opt2018.append(L_int_opt)
     
#defining the dataframes 
df16=pd.DataFrame(L_int_opt2016, columns=['Opt. Measured Int. Lum.']) 
df17=pd.DataFrame(L_int_opt2017, columns=['Opt. Measured Int. Lum.'])  
df18=pd.DataFrame(L_int_opt2018, columns=['Opt. Measured Int. Lum.']) 


#evaluating the total luminosities   
L_tot_2016=[np.sum(L_int_opt2016)]
L_tot_2017=[np.sum(L_int_opt2017)]
L_tot_2018=[np.sum(L_int_opt2018)]

df16tot=pd.DataFrame(L_tot_2016, columns=['Opt. Measured tot. Lum.']) 
df17tot=pd.DataFrame(L_tot_2017, columns=['Opt. Measured tot. Lum.'])  
df18tot=pd.DataFrame(L_tot_2018, columns=['Opt. Measured tot. Lum.']) 

#write dataframes on an excel file
with pd.ExcelWriter('Optimized Measured Luminosity.xlsx') as writer:
        df16.to_excel(writer, sheet_name='2016 Integrated Luminosity')
        df17.to_excel(writer, sheet_name='2017 Integrated Luminosity')
        df18.to_excel(writer, sheet_name='2018 Integrated Luminosity')  
        df16tot.to_excel(writer, sheet_name='2016 Total Luminosity')
        df17tot.to_excel(writer, sheet_name='2017 Total Luminosity')
        df18tot.to_excel(writer, sheet_name='2018 Total Luminosity')

#defining the stop time of the program      
stop=time.time()
#evaluating the run time 
runtime_seq=stop-start
print('The runtime is:', runtime_seq, '[s]')   